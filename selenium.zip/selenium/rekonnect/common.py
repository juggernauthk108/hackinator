from config import Config

from selenium import webdriver
import time
import xlsxwriter
from random import randint
import pyfiglet 
import config




class Shared:
	def initialize_driver():
		options = webdriver.ChromeOptions()
		options.add_argument('ignore-certificate-errors')
		#options.add_argument('--headless')
		options.add_argument('--log-level=3')
		options.add_argument('user-agent=nvegfgad')

		driver = webdriver.Chrome(executable_path="../ChromeDriver/chromedriver.exe", options=options)
		return driver


	def holup(msg=True):
		if msg:
			print("Waiting for Rekonnect...")
		time.sleep(1)


	def login(driver):
		driver.get("https://rekonnect.in.kworld.kpmg.com")
		username=driver.find_element_by_xpath('//input[@id="unamebean"]')
		password=driver.find_element_by_xpath('//input[@id="pwdbean"]')
		submit=driver.find_element_by_xpath('//button[@id="SubmitButton"]')

		username.send_keys(Config.USERNAME)
		password.send_keys(Config.PASSWORD)
	
		submit.click()

		return driver

	def opents(driver):
		Shared.holup()
		time_sheet = driver.find_element_by_xpath('//a[text()="KPMG Time Sheets"]')
		time_sheet.click()

		Shared.holup()
		time_sheet = driver.find_element_by_xpath('//a[text()="Time"]')
		time_sheet.click()

		Shared.holup()
		time_sheet = driver.find_element_by_xpath('//a[text()="Create Timecard"]')
		time_sheet.click()

		return driver

	def get_date_list(driver):
		dates = driver.find_elements_by_xpath('//select[@id="N61"]//option')
		return driver, dates

	def line_items(driver):
		count = 0
		for i in range(1,8):
			code = driver.find_element_by_xpath('//input[@id="A24'+str(i)+'N1display"]').get_attribute("value")
			if code:
				#print("Found a code : "+code)
				count += 1
			else:
				#print("Finished scanning time sheet; Only "+str(count)+" found")
				return driver, count


	def get_oldest_date(driver):
		while True:
			try:
				print("Travelling back in time...")
				dates = driver.find_elements_by_xpath('//select[@id="N61"]//option[contains(text(),"More Periods")]')[1]
		
				dates.click()
				driver, dates = get_date_list(driver)
				Shared.holup()
			except Exception:
				return driver, dates
	
	def welcome():
		result = pyfiglet.figlet_format("KRONOS", font = "slant"  ) 
		print(result)

		print("#"*50)

		print()
		print("Welcome to Kronos - God Of Time.")
		print("DISCLAIMER : For KPMG India - Internal use only!")
		print("Author & Maintainer: Tejas Zarekar")
		print("Email : tejaszarekar@kpmg.com")
		print()
		print("#"*50)

		print()
		print()
		print()








































	