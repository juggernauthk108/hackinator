from selenium import webdriver
import time
import xlsxwriter
from random import randint
import pyfiglet 
from common import Shared
from config import Config

#xlrd is also a req


time_sheet = [["Period", "Project", "TaskCode", "Type", "Sat","Sun","Mon","Tue","Wed","Thu","Fri"]]

def print_ts(driver, count, period):

	for i in range(1,count+1):

		line_item = [period.replace("~","")]		
		
		code = driver.find_element_by_xpath('//input[@id="A24'+str(i)+'N1display"]').get_attribute("value")
		line_item.append(code)
		
		task = driver.find_element_by_xpath('//input[@id="A25'+str(i)+'N1display"]').get_attribute("value")
		line_item.append(task)
		
		type = driver.find_element_by_xpath('//input[@id="A26'+str(i)+'N1display"]').get_attribute("value")
		line_item.append(type)

		#print(period+"\t"+code+"\t"+task+"\t"+type, end="\t")

		
		for j in range(0,7):
			cell = driver.find_element_by_xpath('//input[@id="B22_'   +str(i)+  '_'   +str(j)+  '"]')
			hour = cell.get_attribute("value")
			if hour == "" :
				#print("0", end="\t")
				line_item.append("0")
			else:
				#print(hour, end="\t")	
				line_item.append(str(hour))
		time_sheet.append(line_item)
	print("Successful!", end="\n")
	return driver
		


	

def get_dates(driver):
		
	while True:
		try:
			print("Travelling back in time...")
			dates = driver.find_elements_by_xpath('//select[@id="N61"]//option[contains(text(),"More Periods")]')[1]
		
			dates.click()
			driver, dates = Shared.get_date_list(driver)
			holup()
		except Exception:
			#print("Cant go back in time anymore")
			break
	print("Oldest card is : "+dates[-1].text)
	#print("Opening the last timecard")

	anchor = dates[-1].text
	dates[-1].click()
	

	driver, cards = Shared.get_date_list(driver)

	
	 
	for i in range(0,Config.MAXCARDS+1):

		print("Fetching time card for "+anchor.replace("~","")+" ...", end="")
		
		anchor_elem = driver.find_element_by_xpath("//*[contains(text(),'"+anchor+"')]")
		anchor_elem.click()
		Shared.holup(False)
		driver, count = Shared.line_items(driver)
		#print("printing time sheet...")
		driver = print_ts(driver, count, anchor)

		next_elem = driver.find_element_by_xpath("//*[contains(text(),'"+anchor+"')]/preceding::option[1]")
		anchor = next_elem.text
	
	for i in range(0,5):
		print()
	
	#print(time_sheet)
	print("Writing to excel")
	
	suffix = str(randint(0,99999))
	
	with xlsxwriter.Workbook('my_time_sheet'+suffix+'.xlsx') as workbook:
		worksheet = workbook.add_worksheet()
		for row_num, data in enumerate(time_sheet):
			worksheet.write_row(row_num, 0, data)
	
	print("Time sheet saved locally at my_time_sheet"+suffix+".xlsx")
	print("\nThank you for using Kronos")
	return driver




def fetch():
	try:
		Shared.welcome()
		print("Starting KPMG time sheet automation")
		driver = Shared.initialize_driver()
		print("Attempting login")
		driver = Shared.login(driver)
		print("Login Successful!")
		driver = Shared.opents(driver)
		#print("Getting dates of timesheet")
		driver = get_dates(driver)
		#time.sleep(200)
		driver.close()
	except Exception as e:
		print(e)
		print("\n\nSomething went wrong!")
		print("Please check your VPN connection, login credentials and restart Kronos.\n")

if __name__ == "__main__":
	fetch()

