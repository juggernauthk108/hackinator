from selenium import webdriver
from time import time
import time
import xlsxwriter
from random import randint

def holup(msg=True):
	if msg:
		print("Waiting for Rekonnect...")
	time.sleep(1)

def initialize_driver():
	options = webdriver.ChromeOptions()
	options.add_argument('ignore-certificate-errors')
	#options.add_argument('--headless')
	options.add_argument('--log-level=3')
	options.add_argument('user-agent=nvegfgad')

	driver = webdriver.Chrome(executable_path="../ChromeDriver/chromedriver.exe", options=options)
	return driver


def login(driver):
	driver.get("https://rekonnect.in.kworld.kpmg.com")
	username=driver.find_element_by_xpath('//input[@id="unamebean"]')
	password=driver.find_element_by_xpath('//input[@id="pwdbean"]')
	submit=driver.find_element_by_xpath('//button[@id="SubmitButton"]')

	username.send_keys("tejaszarekar")
	password.send_keys("fandango123!")
	
	submit.click()

	return driver

def opents(driver):
	holup()
	time_sheet = driver.find_element_by_xpath('//a[text()="KPMG Time Sheets"]')
	time_sheet.click()

	holup()
	time_sheet = driver.find_element_by_xpath('//a[text()="Time"]')
	time_sheet.click()

	holup()
	time_sheet = driver.find_element_by_xpath('//a[text()="Create Timecard"]')
	time_sheet.click()

	return driver

def get_date_list(driver):
	dates = driver.find_elements_by_xpath('//select[@id="N61"]//option')
	return driver, dates

def line_items(driver):
	count = 0
	for i in range(1,8):
		code = driver.find_element_by_xpath('//input[@id="A24'+str(i)+'N1display"]').get_attribute("value")
		if code:
			#print("Found a code : "+code)
			count += 1
		else:
			#print("Finished scanning time sheet; Only "+str(count)+" found")
			return driver, count

time_sheet = [["Period", "Project", "TaskCode", "Type", "Sat","Sun","Mon","Tue","Wed","Thu","Fri"]]

def print_ts(driver, count, period):


	for i in range(1,count+1):

		line_item = [period.replace("~","")]		
		
		code = driver.find_element_by_xpath('//input[@id="A24'+str(i)+'N1display"]').get_attribute("value")
		line_item.append(code)
		
		task = driver.find_element_by_xpath('//input[@id="A25'+str(i)+'N1display"]').get_attribute("value")
		line_item.append(task)
		
		type = driver.find_element_by_xpath('//input[@id="A26'+str(i)+'N1display"]').get_attribute("value")
		line_item.append(type)

		#print(period+"\t"+code+"\t"+task+"\t"+type, end="\t")

		
		for j in range(0,7):
			cell = driver.find_element_by_xpath('//input[@id="B22_'   +str(i)+  '_'   +str(j)+  '"]')
			hour = cell.get_attribute("value")
			if hour == "" :
				#print("0", end="\t")
				line_item.append("0")
			else:
				#print(hour, end="\t")	
				line_item.append(str(hour))
		time_sheet.append(line_item)
	print("Successful!", end="\n")
	return driver
		

def get_dates(driver):
		
	while True:
		try:
			print("Travelling back in time...")
			dates = driver.find_elements_by_xpath('//select[@id="N61"]//option[contains(text(),"More Periods")]')[1]
		
			dates.click()
			driver, dates = get_date_list(driver)
			holup()
		except Exception:
			#print("Cant go back in time anymore")
			break
	print("Oldest card is : "+dates[-1].text)
	#print("Opening the last timecard")
	dates[-1].click()

	driver, cards = get_date_list(driver)
	
	periods = []
	for c in cards:
		periods.append(c.text)		

	
	#print("LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOPING")
	for period in periods[::-1]:
		if "More" in period:
			#print("Not authorized for next iteration.. Shutting Down!")
			break

		#print("Going for "+period)
		print("Accessing time card for "+period.replace("~","")+" ...", end="")
		driver, periods = get_date_list(driver)
		button = driver.find_element_by_xpath('//*[contains(text(),"'+period+'")]')
		button.click()
		holup(False)
		driver, count = line_items(driver)
		#print("printing time sheet...")
		driver = print_ts(driver, count, period)
		
	#print("LOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOPING DONE!!!")
	
	for i in range(0,5):
		print()
	
	#print(time_sheet)
	print("Writing to excel")
	
	suffix = str(randint(0,99999))
	
	with xlsxwriter.Workbook('my_time_sheet'+suffix+'.xlsx') as workbook:
		worksheet = workbook.add_worksheet()
		for row_num, data in enumerate(time_sheet):
			worksheet.write_row(row_num, 0, data)
	
	print("Time sheet saved locally at my_time_sheet"+suffix+".xlsx")
	print("Thank you for using Kronos")
	return driver

import pyfiglet 
  
result = pyfiglet.figlet_format("KRONOS", font = "slant"  ) 
print(result)

print("#"*50)
print("Welcome to Kronos - God Of Time.")
print("#"*50)
print()
print()
print()


print("Starting KPMG time sheet automation")
driver = initialize_driver()
print("Attempting login")
driver = login(driver)
#print("Opening timesheet page")
driver = opents(driver)
#print("Getting dates of timesheet")
driver = get_dates(driver)
#time.sleep(200)
driver.close()

