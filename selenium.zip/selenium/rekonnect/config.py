class Config:
	
	#MAXCARDS is the number of time-cards you want from the last editable card
	#You can go back 8 weeks from current week
	
	USERNAME="tejaszarekar"
	PASSWORD="fandango123!"
	MAXCARDS=2