import pandas as pd
import ts


def business():
	print("Starting KPMG time sheet automated time entry")
	driver = ts.initialize_driver()
	print("Attempting login")
	driver = login(driver)
	driver = opents(driver)
	return driver

def get_to_start_date(driver):
	driver, cards = get_date_list(driver)
	print(list)
	return

def submit_ts(driver):
	return
	

def write_ts(driver, line_item):
	driver = get_to_start_date(driver, line_item)
	driver = populate_ts(driver, line_item)
	driver = submit_ts(driver)

def initiate_entry(df):
	driver = business()
	
	for i in df.itertuples():
		write_ts(driver, list(i))
		break


df = pd.read_excel("./template.xlsx", dtype=str)

try:
	start = df[df["Action"]=="Start"].index[0]
	stop = df[df["Action"]=="Stop"].index[0] + 1
except:
	print("Template is corrupt. Please try again with proper input template")
	exit(-1)

df=df[start:stop]

initiate_entry(df)

